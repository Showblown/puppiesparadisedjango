from django.db import models

class Dates(models.Model):
    days = models.IntegerField()
# Create your models here.
