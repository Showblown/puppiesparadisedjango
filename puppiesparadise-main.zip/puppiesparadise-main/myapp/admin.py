from django.contrib import admin
from .models import Dates

admin.site.register(Dates)
# Register your models here.
